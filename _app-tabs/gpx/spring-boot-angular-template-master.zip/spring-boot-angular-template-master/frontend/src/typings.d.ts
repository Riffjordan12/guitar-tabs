/* SystemJS module definition */
declare var jQuery: any;
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
