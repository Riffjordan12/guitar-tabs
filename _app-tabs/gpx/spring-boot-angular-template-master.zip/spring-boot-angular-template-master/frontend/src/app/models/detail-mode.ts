export enum DetailMode {
  UNDEFINED,
  NEW,
  EDIT
}
