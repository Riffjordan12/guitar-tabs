export type AuthGroup = 'ROLE_USER' | 'ROLE_ADMIN';
