export interface TemplateRoleRaw {
  id: string;
  description: string;
  authority: string;
}
