export interface Person {
  id: string;
  firstname: string;
  lastname: string;
}
