export class TemplateRole {
  constructor(
    public id: string,
    public description: string
  ) {}
}
