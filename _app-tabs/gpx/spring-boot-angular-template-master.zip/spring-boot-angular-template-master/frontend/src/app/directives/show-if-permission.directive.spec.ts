import { TestBed } from '@angular/core/testing';
import { ShowIfPermissionDirective } from './show-if-permission.directive';

describe('ShowIfPermissionDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ShowIfPermissionDirective]
    });
  });
});
