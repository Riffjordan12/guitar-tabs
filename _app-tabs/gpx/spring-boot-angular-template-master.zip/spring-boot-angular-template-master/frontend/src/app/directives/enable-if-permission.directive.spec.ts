import { TestBed } from '@angular/core/testing';
import { EnableIfPermissionDirective } from './enable-if-permission.directive';

describe('EnableIfPermissionDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EnableIfPermissionDirective]
    });
  });
});
