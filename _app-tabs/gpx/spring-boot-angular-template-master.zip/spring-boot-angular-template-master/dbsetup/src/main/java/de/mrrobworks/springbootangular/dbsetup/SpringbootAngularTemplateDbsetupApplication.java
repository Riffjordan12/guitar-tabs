package de.mrrobworks.springbootangular.dbsetup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAngularTemplateDbsetupApplication {

  public static void main(String[] args) {
    SpringApplication.run(SpringbootAngularTemplateDbsetupApplication.class, args);
  }
}
