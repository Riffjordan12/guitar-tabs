INSERT INTO app_role VALUES('ROLE_ADMIN', 'Administrator');
INSERT INTO app_role VALUES('ROLE_USER', 'Normal User');

INSERT INTO person VALUES(1, 'firstname1', 'lastname1');
INSERT INTO person VALUES(2, 'firstname2', 'lastname2');
