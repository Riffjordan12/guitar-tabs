#!/bin/bash
java -jar ${jar-artifact}