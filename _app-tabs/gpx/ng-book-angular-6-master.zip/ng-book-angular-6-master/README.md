# ng-book-angular-6
Examples and Exercises from the "ng-book: The Complete Book on Angular 6" by Nate Murray, Felipe Coury, Ari Lerner and Carlos Taborda.
