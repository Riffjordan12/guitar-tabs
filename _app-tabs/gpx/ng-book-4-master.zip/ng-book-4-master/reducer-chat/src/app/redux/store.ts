// class Store<T> {
// 	private _state: T;

// }