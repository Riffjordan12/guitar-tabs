import { FromNowPipe } from './from-now.pipe';

describe('FromNowPipe', () => {
  it('create an instance', () => {
    const pipe = new FromNowPipe();
    expect(pipe).toBeTruthy();
  });
});
